:mod:`authpam.py` - A PAM Authentication Module
===============================================

.. moduleauthor:: Alan Schmitz (Thanks!)

.. automodule:: authpam
    :members:
    :private-members:
