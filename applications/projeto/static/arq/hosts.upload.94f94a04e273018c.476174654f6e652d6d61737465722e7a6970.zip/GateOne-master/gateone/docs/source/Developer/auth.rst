:mod:`auth.py` - Authentication Classes
=======================================

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>

.. automodule:: auth
    :members:
    :private-members:
