The Logging Plugin
==================

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>

JavaScript
----------

logging.js - The client-side portion of Gate One's Logging plugin.

.. autojs:: ../applications/terminal/plugins/logging/static/logging.js
    :members:

Python
------

.. automodule:: logging_plugin
    :members:
    :private-members:
