.. _example-plugin:

The Example Plugin
==================

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>

JavaScript
----------

example.js - The client-side portion of Gate One's Example plugin.

.. autojs:: ../applications/terminal/plugins/example/static/example.js
    :members:

Python
------
.. automodule:: example
    :members:
    :private-members:
